from __future__ import annotations
import os, re, hmac, hashlib, secrets, json, uuid, mimetypes
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form, Header
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, String, Text, DateTime, ForeignKey, Integer, Float, Boolean, select, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker, Session

BASE = Path(__file__).resolve().parent
STATIC = BASE / 'static'
UPLOAD_DIR = Path(os.getenv('UPLOAD_DIR', './data/uploads'))
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///./data/portal.db')
if DATABASE_URL.startswith('sqlite'):
    Path('./data').mkdir(exist_ok=True)
connect_args = {'check_same_thread': False} if DATABASE_URL.startswith('sqlite') else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
SECRET = os.getenv('APP_SECRET', 'dev-only-change-this-secret')
MAX_UPLOAD_MB = int(os.getenv('MAX_UPLOAD_MB', '15'))

class Base(DeclarativeBase): pass
class User(Base):
    __tablename__='users'
    id: Mapped[int]=mapped_column(Integer, primary_key=True)
    username: Mapped[str]=mapped_column(String(80), unique=True, index=True)
    password_hash: Mapped[str]=mapped_column(String(300))
    role: Mapped[str]=mapped_column(String(20), default='staff')
    active: Mapped[bool]=mapped_column(Boolean, default=True)
    created_at: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow)
class Case(Base):
    __tablename__='cases'
    id: Mapped[int]=mapped_column(Integer, primary_key=True)
    case_no: Mapped[str]=mapped_column(String(60), unique=True, index=True)
    customer: Mapped[str]=mapped_column(String(200), default='')
    exporter: Mapped[str]=mapped_column(String(300), default='')
    importer: Mapped[str]=mapped_column(String(300), default='')
    shipment_ref: Mapped[str]=mapped_column(String(120), default='')
    status: Mapped[str]=mapped_column(String(40), default='Mới tiếp nhận')
    assigned_to: Mapped[str]=mapped_column(String(80), default='')
    notes: Mapped[str]=mapped_column(Text, default='')
    created_by: Mapped[str]=mapped_column(String(80), default='')
    created_at: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    documents: Mapped[list['Document']]=relationship(back_populates='case', cascade='all, delete-orphan')
class Document(Base):
    __tablename__='documents'
    id: Mapped[int]=mapped_column(Integer, primary_key=True)
    case_id: Mapped[int]=mapped_column(ForeignKey('cases.id'))
    original_name: Mapped[str]=mapped_column(String(255))
    stored_name: Mapped[str]=mapped_column(String(255), unique=True)
    doc_type: Mapped[str]=mapped_column(String(80), default='Khác')
    mime_type: Mapped[str]=mapped_column(String(120), default='application/octet-stream')
    extracted_text: Mapped[str]=mapped_column(Text, default='')
    extracted_json: Mapped[str]=mapped_column(Text, default='{}')
    uploaded_by: Mapped[str]=mapped_column(String(80), default='')
    created_at: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow)
    case: Mapped[Case]=relationship(back_populates='documents')
class Audit(Base):
    __tablename__='audit_logs'
    id: Mapped[int]=mapped_column(Integer, primary_key=True)
    username: Mapped[str]=mapped_column(String(80), default='')
    action: Mapped[str]=mapped_column(String(100))
    entity_type: Mapped[str]=mapped_column(String(50), default='')
    entity_id: Mapped[str]=mapped_column(String(80), default='')
    detail: Mapped[str]=mapped_column(Text, default='')
    created_at: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow)

Base.metadata.create_all(engine)

def db():
    s=SessionLocal()
    try: yield s
    finally: s.close()

def hash_password(password: str) -> str:
    salt=secrets.token_hex(16)
    digest=hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 310000).hex()
    return f'pbkdf2_sha256${salt}${digest}'
def verify_password(password: str, stored: str) -> bool:
    try:
        _,salt,digest=stored.split('$',2)
        return hmac.compare_digest(hashlib.pbkdf2_hmac('sha256',password.encode(),salt.encode(),310000).hex(),digest)
    except Exception: return False
def token_for(user: User) -> str:
    import base64
    payload=json.dumps({'sub':user.username,'role':user.role,'exp':int((datetime.now(timezone.utc)+timedelta(hours=12)).timestamp())}, separators=(',',':')).encode()
    body=base64.urlsafe_b64encode(payload).decode().rstrip('=')
    sig=hmac.new(SECRET.encode(),body.encode(),hashlib.sha256).hexdigest()
    return body+'.'+sig
def current_user(authorization: Optional[str]=Header(None), s: Session=Depends(db)) -> User:
    import base64
    if not authorization or not authorization.startswith('Bearer '): raise HTTPException(401,'Vui lòng đăng nhập')
    token=authorization[7:]
    try:
        body,sig=token.rsplit('.',1)
        expected=hmac.new(SECRET.encode(),body.encode(),hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig,expected): raise ValueError()
        payload=json.loads(base64.urlsafe_b64decode(body+'='*((4-len(body)%4)%4)))
        if payload['exp'] < int(datetime.now(timezone.utc).timestamp()): raise ValueError()
        user=s.scalar(select(User).where(User.username==payload['sub'],User.active==True))
        if not user: raise ValueError()
        return user
    except Exception: raise HTTPException(401,'Phiên đăng nhập không hợp lệ hoặc đã hết hạn')
def admin_user(user: User=Depends(current_user)) -> User:
    if user.role!='admin': raise HTTPException(403,'Chức năng chỉ dành cho quản trị viên')
    return user
def audit(s: Session, user: str, action: str, entity_type='', entity_id='', detail=''):
    s.add(Audit(username=user,action=action,entity_type=entity_type,entity_id=str(entity_id),detail=detail[:4000]))

def seed_admin():
    with SessionLocal() as s:
        if not s.scalar(select(User).limit(1)):
            username=os.getenv('ADMIN_USERNAME','admin')
            password=os.getenv('ADMIN_PASSWORD','ChangeThisNow_123!')
            s.add(User(username=username,password_hash=hash_password(password),role='admin'))
            s.commit()
seed_admin()

app=FastAPI(title='U&I C/O Portal', version='1.0.0', description='Hệ thống quản lý hồ sơ C/O Form E và rà soát chứng từ')
app.mount('/static',StaticFiles(directory=STATIC),name='static')
@app.get('/',response_class=HTMLResponse)
def home(): return FileResponse(STATIC/'index.html')
@app.get('/health')
def health(): return {'status':'ok','service':'U&I C/O Portal','time':datetime.utcnow().isoformat()}

class LoginIn(BaseModel): username:str; password:str
class CaseIn(BaseModel):
    case_no: str = Field(min_length=2,max_length=60)
    customer: str = ''
    exporter: str = ''
    importer: str = ''
    shipment_ref: str = ''
    status: str = 'Mới tiếp nhận'
    assigned_to: str = ''
    notes: str = ''
class CaseUpdate(BaseModel):
    customer: Optional[str]=None; exporter: Optional[str]=None; importer: Optional[str]=None
    shipment_ref: Optional[str]=None; status: Optional[str]=None; assigned_to: Optional[str]=None; notes: Optional[str]=None
class UserIn(BaseModel): username:str=Field(min_length=3,max_length=80); password:str=Field(min_length=12); role:str='staff'

@app.post('/api/login')
def login(data: LoginIn,s:Session=Depends(db)):
    user=s.scalar(select(User).where(User.username==data.username))
    if not user or not user.active or not verify_password(data.password,user.password_hash):
        raise HTTPException(401,'Tên đăng nhập hoặc mật khẩu không đúng')
    audit(s,user.username,'Đăng nhập','user',user.id); s.commit()
    return {'token':token_for(user),'username':user.username,'role':user.role}
@app.get('/api/me')
def me(user:User=Depends(current_user)):
    return {'username':user.username,'role':user.role}
@app.post('/api/users')
def create_user(data:UserIn,s:Session=Depends(db),user:User=Depends(admin_user)):
    if data.role not in ('staff','reviewer','admin'): raise HTTPException(400,'Vai trò không hợp lệ')
    if s.scalar(select(User).where(User.username==data.username)): raise HTTPException(409,'Tên đăng nhập đã tồn tại')
    u=User(username=data.username,password_hash=hash_password(data.password),role=data.role)
    s.add(u); s.flush(); audit(s,user.username,'Tạo người dùng','user',u.id,f'username={u.username}; role={u.role}'); s.commit()
    return {'id':u.id,'username':u.username,'role':u.role}
@app.get('/api/users')
def users(s:Session=Depends(db),user:User=Depends(admin_user)):
    return [{'id':u.id,'username':u.username,'role':u.role,'active':u.active} for u in s.scalars(select(User).order_by(User.username))]

@app.get('/api/dashboard')
def dashboard(s:Session=Depends(db),user:User=Depends(current_user)):
    cases=list(s.scalars(select(Case).order_by(Case.updated_at.desc())))
    docs=s.scalar(select(func.count(Document.id))) or 0
    audits=list(s.scalars(select(Audit).order_by(Audit.created_at.desc()).limit(8)))
    return {'total_cases':len(cases),'active_cases':sum(c.status not in ('Hoàn tất','Đã hủy') for c in cases),'needs_review':sum(c.status in ('Chờ kiểm tra','Cần bổ sung','Có cảnh báo') for c in cases),'documents':docs,
      'cases':[case_json(c,include_docs=False) for c in cases[:8]],'activity':[{'username':a.username,'action':a.action,'detail':a.detail,'created_at':a.created_at.isoformat()} for a in audits]}
def case_json(c:Case,include_docs=True):
    x={'id':c.id,'case_no':c.case_no,'customer':c.customer,'exporter':c.exporter,'importer':c.importer,'shipment_ref':c.shipment_ref,'status':c.status,'assigned_to':c.assigned_to,'notes':c.notes,'created_by':c.created_by,'created_at':c.created_at.isoformat(),'updated_at':c.updated_at.isoformat()}
    if include_docs: x['documents']=[doc_json(d) for d in c.documents]
    return x
def doc_json(d:Document):
    try: fields=json.loads(d.extracted_json or '{}')
    except Exception: fields={}
    return {'id':d.id,'original_name':d.original_name,'doc_type':d.doc_type,'mime_type':d.mime_type,'extracted_text':d.extracted_text[:12000],'fields':fields,'uploaded_by':d.uploaded_by,'created_at':d.created_at.isoformat()}
@app.get('/api/cases')
def list_cases(q:str='',status:str='',s:Session=Depends(db),user:User=Depends(current_user)):
    stmt=select(Case).order_by(Case.updated_at.desc())
    if status: stmt=stmt.where(Case.status==status)
    if q:
        pat=f'%{q}%'; stmt=stmt.where((Case.case_no.ilike(pat))|(Case.customer.ilike(pat))|(Case.exporter.ilike(pat))|(Case.shipment_ref.ilike(pat)))
    return [case_json(c,False) for c in s.scalars(stmt)]
@app.post('/api/cases')
def create_case(data:CaseIn,s:Session=Depends(db),user:User=Depends(current_user)):
    if s.scalar(select(Case).where(Case.case_no==data.case_no)): raise HTTPException(409,'Mã hồ sơ đã tồn tại')
    c=Case(**data.model_dump(),created_by=user.username); s.add(c); s.flush(); audit(s,user.username,'Tạo hồ sơ','case',c.id,c.case_no); s.commit(); s.refresh(c)
    return case_json(c)
@app.get('/api/cases/{case_id}')
def get_case(case_id:int,s:Session=Depends(db),user:User=Depends(current_user)):
    c=s.get(Case,case_id)
    if not c: raise HTTPException(404,'Không tìm thấy hồ sơ')
    return case_json(c)
@app.patch('/api/cases/{case_id}')
def update_case(case_id:int,data:CaseUpdate,s:Session=Depends(db),user:User=Depends(current_user)):
    c=s.get(Case,case_id)
    if not c: raise HTTPException(404,'Không tìm thấy hồ sơ')
    changes={k:v for k,v in data.model_dump(exclude_none=True).items() if getattr(c,k)!=v}
    for k,v in changes.items(): setattr(c,k,v)
    c.updated_at=datetime.utcnow(); audit(s,user.username,'Cập nhật hồ sơ','case',c.id,json.dumps(changes,ensure_ascii=False)); s.commit(); s.refresh(c)
    return case_json(c)

# Extraction: PDF text layer first, then OCR; model-assisted parsing only when API key is configured.
def extract_text(path:Path, mime_type:str) -> str:
    text=''
    try:
        if path.suffix.lower()=='.pdf':
            import fitz
            doc=fitz.open(path)
            text='\n'.join(page.get_text('text') for page in doc)
            if len(text.strip())<40:
                try:
                    import pytesseract
                    from PIL import Image
                    import io
                    text='\n'.join(pytesseract.image_to_string(page.get_pixmap(matrix=fitz.Matrix(2,2)).tobytes('png'),lang='eng+vie') for page in [])
                    # OCR page-by-page with Pillow images
                    chunks=[]
                    for page in doc:
                        pix=page.get_pixmap(matrix=fitz.Matrix(2,2)); img=Image.open(io.BytesIO(pix.tobytes('png')))
                        chunks.append(pytesseract.image_to_string(img,lang='eng+vie'))
                    text='\n'.join(chunks)
                except Exception: pass
        elif path.suffix.lower() in ('.png','.jpg','.jpeg','.tif','.tiff','.bmp','.webp'):
            try:
                import pytesseract
                from PIL import Image
                text=pytesseract.image_to_string(Image.open(path),lang='eng+vie')
            except Exception: pass
        elif path.suffix.lower() in ('.txt','.csv'):
            text=path.read_text(errors='ignore')[:200000]
    except Exception: pass
    return text[:200000]

def regex_extract(text:str) -> dict:
    t=text or ''
    def find(patterns):
        for p in patterns:
            m=re.search(p,t,re.I|re.M)
            if m: return re.sub(r'\s+',' ',m.group(1)).strip(' :#-\t')[:250]
        return ''
    invoice=find([r'(?:invoice\s*(?:no\.?|number|#)|số\s*hóa\s*đơn)\s*[:#-]?\s*([A-Z0-9][A-Z0-9./_-]{2,})'])
    date=find([r'(?:invoice\s*date|date|ngày\s*hóa\s*đơn|ngày)\s*[:#-]?\s*([0-3]?\d[./-][01]?\d[./-](?:20)?\d\d)',r'(?:invoice\s*date|date)\s*[:#-]?\s*((?:19|20)\d\d-[01]?\d-[0-3]?\d)'])
    currency=find([r'(?:currency|tiền\s*tệ)\s*[:#-]?\s*(USD|VND|CNY|EUR|JPY|THB|SGD)'])
    hs=list(dict.fromkeys(re.findall(r'\b\d{4,10}(?:\.\d{2})?\b',t)))[:30]
    amount=find([r'(?:total\s*(?:invoice\s*)?value|grand\s*total|total\s*amount|FOB\s*(?:value)?|tổng\s*trị\s*giá)\s*[:#-]?\s*([A-Z]{0,3}\s*[\d,]+(?:\.\d{2})?)'])
    exporter=find([r'(?:exporter|seller|shipper|người\s*xuất\s*khẩu)\s*[:\n]+([^\n]{3,180})'])
    importer=find([r'(?:consignee|buyer|importer|người\s*nhập\s*khẩu)\s*[:\n]+([^\n]{3,180})'])
    return {'invoice_no':invoice,'date':date,'currency':currency,'total_value':amount,'exporter':exporter,'importer':importer,'hs_codes':hs,'extraction_method':'OCR + pattern matching','review_required':True}

def ai_extract(text:str, doc_type:str) -> Optional[dict]:
    key=os.getenv('OPENAI_API_KEY','').strip()
    if not key or not text.strip(): return None
    try:
        from openai import OpenAI
        client=OpenAI(api_key=key)
        resp=client.chat.completions.create(model=os.getenv('OPENAI_MODEL','gpt-4.1-mini'),temperature=0,response_format={'type':'json_object'},messages=[
          {'role':'system','content':'Extract fields from trade/shipping documents. Return JSON only with keys invoice_no,date,currency,total_value,exporter,importer,consignee,shipment_ref,hs_codes,quantity,unit,document_type,uncertain_fields. Use empty strings or [] when absent. Never infer missing values. Mark uncertain fields. This is an extraction aid, not a legal or origin determination.'},
          {'role':'user','content':f'Document type label: {doc_type}\nText:\n{text[:18000]}'}])
        data=json.loads(resp.choices[0].message.content or '{}'); data['extraction_method']='AI-assisted extraction'; data['review_required']=True
        return data
    except Exception: return None

@app.post('/api/cases/{case_id}/documents')
def upload_document(case_id:int,file:UploadFile=File(...),doc_type:str=Form('Khác'),s:Session=Depends(db),user:User=Depends(current_user)):
    c=s.get(Case,case_id)
    if not c: raise HTTPException(404,'Không tìm thấy hồ sơ')
    name=Path(file.filename or 'upload.bin').name
    ext=Path(name).suffix.lower()
    allowed={'.pdf','.png','.jpg','.jpeg','.tif','.tiff','.bmp','.webp','.txt','.csv'}
    if ext not in allowed: raise HTTPException(415,'Chỉ nhận PDF, ảnh, TXT hoặc CSV ở phiên bản này')
    stored=f'{uuid.uuid4().hex}{ext}'; path=UPLOAD_DIR/stored
    content=file.file.read(MAX_UPLOAD_MB*1024*1024+1)
    if len(content)>MAX_UPLOAD_MB*1024*1024: raise HTTPException(413,f'Tệp vượt quá {MAX_UPLOAD_MB} MB')
    path.write_bytes(content)
    text=extract_text(path,file.content_type or '')
    fields=ai_extract(text,doc_type) or regex_extract(text)
    d=Document(case_id=case_id,original_name=name,stored_name=stored,doc_type=doc_type,mime_type=file.content_type or mimetypes.guess_type(name)[0] or 'application/octet-stream',extracted_text=text,extracted_json=json.dumps(fields,ensure_ascii=False),uploaded_by=user.username)
    s.add(d); c.updated_at=datetime.utcnow(); audit(s,user.username,'Tải lên và đọc chứng từ','document',stored,f'{c.case_no} | {name} | method={fields.get("extraction_method")}'); s.commit(); s.refresh(d)
    return doc_json(d)
@app.get('/api/documents/{document_id}/download')
def download_document(document_id:int,s:Session=Depends(db),user:User=Depends(current_user)):
    d=s.get(Document,document_id)
    if not d: raise HTTPException(404,'Không tìm thấy chứng từ')
    path=UPLOAD_DIR/d.stored_name
    if not path.exists(): raise HTTPException(404,'Tệp không còn trên máy chủ')
    return FileResponse(path,filename=d.original_name,media_type=d.mime_type)

@app.get('/api/cases/{case_id}/compare')
def compare_documents(case_id:int,s:Session=Depends(db),user:User=Depends(current_user)):
    c=s.get(Case,case_id)
    if not c: raise HTTPException(404,'Không tìm thấy hồ sơ')
    docs=list(c.documents)
    fields=[]
    for d in docs:
        try: parsed=json.loads(d.extracted_json or '{}')
        except: parsed={}
        fields.append({'document':d.original_name,'type':d.doc_type,'fields':parsed})
    # Compare only explicit, non-empty values. Similar-but-not-identical names are flagged for human review.
    keys=[('invoice_no','Số hóa đơn'),('date','Ngày chứng từ'),('currency','Tiền tệ'),('total_value','Tổng trị giá'),('exporter','Người xuất khẩu'),('importer','Người nhập khẩu'),('shipment_ref','Mã lô hàng / vận đơn')]
    alerts=[]
    for key,label in keys:
        vals=[]
        for item in fields:
            value=item['fields'].get(key,'')
            if isinstance(value,str): value=value.strip()
            if value: vals.append((item['document'],str(value)))
        distinct={re.sub(r'\s+',' ',v).casefold() for _,v in vals}
        if len(distinct)>1:
            alerts.append({'field':key,'label':label,'severity':'review','values':[{'document':n,'value':v} for n,v in vals],'message':f'{label} có giá trị khác nhau giữa các chứng từ; cần đối chiếu bản gốc.'})
    if not docs: alerts.append({'field':'documents','label':'Chứng từ','severity':'warning','values':[],'message':'Chưa có chứng từ để đối chiếu.'})
    if len(docs)<3: alerts.append({'field':'coverage','label':'Độ bao phủ','severity':'warning','values':[],'message':'Có ít hơn 3 chứng từ; kết quả đối chiếu có thể chưa đầy đủ.'})
    return {'case_no':c.case_no,'documents_checked':len(docs),'alerts':alerts,'documents':fields,'disclaimer':'Cảnh báo chỉ dựa trên trường dữ liệu trích xuất được. Không phải kết luận pháp lý hay xác nhận điều kiện xuất xứ. Nhân viên phải kiểm tra chứng từ gốc; OCR/AI có thể đọc sai.'}
@app.get('/api/audit')
def audit_logs(limit:int=50,s:Session=Depends(db),user:User=Depends(current_user)):
    limit=max(1,min(limit,200))
    rows=s.scalars(select(Audit).order_by(Audit.created_at.desc()).limit(limit))
    return [{'id':a.id,'username':a.username,'action':a.action,'entity_type':a.entity_type,'entity_id':a.entity_id,'detail':a.detail,'created_at':a.created_at.isoformat()} for a in rows]
@app.get('/api/export')
def export_data(s:Session=Depends(db),user:User=Depends(admin_user)):
    cases=list(s.scalars(select(Case).order_by(Case.id)))
    return {'exported_at':datetime.utcnow().isoformat(),'cases':[case_json(c) for c in cases]}
