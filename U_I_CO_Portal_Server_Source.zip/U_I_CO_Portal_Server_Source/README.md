# U&I C/O Portal — multi-user pilot

A deployable web application for shared C/O Form E case management, document upload, OCR/AI-assisted extraction, cross-document mismatch alerts, role-based accounts, and audit logs. This is a pilot foundation, not a certified customs/origin determination system.

## Run locally or on a server

Requirements: Docker Engine + Docker Compose.

1. Copy `.env.example` to `.env`.
2. Set a strong unique `APP_SECRET` and change `ADMIN_PASSWORD` before first start. Never deploy with the example password/secret.
3. Optionally set `OPENAI_API_KEY` to enable model-assisted structured extraction. Without it, the app uses local OCR (Tesseract) and conservative pattern matching.
4. Run `docker compose up --build -d`.
5. Open `http://localhost:8000` on the host machine. Other computers on the same network can use `http://SERVER-LAN-IP:8000` if firewall/network rules allow it.
6. Log in using `ADMIN_USERNAME` and `ADMIN_PASSWORD` configured before the first start. Create individual user accounts in **Người dùng**. Do not share accounts.

Data persists in the Docker volume `portal_data` under `/data`. Back it up before upgrades or migration. For production Internet exposure, put the app behind HTTPS reverse proxy, restrict access, configure firewall, backups, monitoring and an operational recovery plan. Do not expose port 8000 directly to the public Internet.

## What works

- Shared server-side database (SQLite volume for a small pilot; PostgreSQL is recommended for production/higher concurrency).
- Login, role distinction (admin/staff/reviewer), admin user creation.
- Create/update/search/filter cases and assign staff.
- Upload PDF, common image formats, TXT/CSV. File size limit configurable via `MAX_UPLOAD_MB` (default 15 MB).
- PDF text extraction; OCR on scanned PDFs/images when Tesseract is available.
- Optional OpenAI structured extraction using `OPENAI_API_KEY`.
- Cross-document comparison for invoice number, date, currency, value, exporter/importer and shipment reference.
- Audit events and JSON export endpoint for admins (`GET /api/export`).
- Health endpoint (`GET /health`).

## Important limitations / production checklist

- Extraction is assistive and may be wrong. All values need human verification against original documents.
- The comparison is conservative: it flags different extracted strings; it is not a full trade-document rules engine and may produce false positives/negatives.
- It does not automatically decide WO/PE/CTC/RVC qualification, issue a C/O, or connect to eCoSys/VCCI/ECUS.
- OCR and AI may process confidential commercial data. Only use the AI API after company approval, a data-processing review, and appropriate contractual/security controls. The app does not send files directly to AI; it sends extracted text only when AI is configured.
- No email/OTP, password reset, account lockout, malware scanning, document redaction, MFA, or formal compliance certification yet. Add these before production use with real customer data.
- The pilot uses SQLite. Before larger production deployment, migrate to PostgreSQL, configure HTTPS, reverse proxy, access restrictions, secret management, backups/restore drills, retention policies and security review.
- Set a strong secret and password. Do not reuse the example credentials. The initial admin is seeded only if the user table is empty on first startup.

## API docs

Interactive API documentation: `http://localhost:8000/docs` (protect or disable this in public production deployments).

## Optional: deploy online with Render

The included `render.yaml` is a starting point for a small always-on web service with a persistent disk. Push this folder to a private Git repository, create a Render Blueprint from that repository, and enter a strong `ADMIN_PASSWORD` and (only if approved) `OPENAI_API_KEY` when prompted. Review the service plan, disk cost, data location, access controls and contractual terms before deploying. Do not commit `.env` or customer documents to Git. After deployment, test login, upload, comparison, backup and restore before using any real operational data. A persistent disk and HTTPS do not by themselves make the application compliant or production-hardened.
